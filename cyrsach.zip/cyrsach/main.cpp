#include "BattleshipGame.h"

int main() {
    BattleshipGame game; // Створюємо об'єкт гри BattleshipGame
    game.play(); // Запускаємо гру
    return 0;
}
